package dora.taptoshare

import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/** 送受信の各段階を記録する診断ログ(診断画面で確認・コピーできる)。 */
object Dbg {
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Synchronized fun d(msg: String) {
        lines.addLast("${fmt.format(Date())} $msg")
        while (lines.size > 400) lines.removeFirst()
        android.util.Log.d("TapShare", msg)
    }

    @Synchronized fun dump(): String = lines.joinToString("\n")
    @Synchronized fun clear() = lines.clear()
}
