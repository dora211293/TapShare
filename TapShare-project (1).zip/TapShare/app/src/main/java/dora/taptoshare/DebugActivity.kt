package dora.taptoshare

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.wifi.WifiManager
import android.nfc.NfcAdapter
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*

class DebugActivity : Activity() {
    private val bg = 0xFF0B1020.toInt()
    private lateinit var checkV: TextView
    private lateinit var logV: TextView
    private lateinit var scroll: ScrollView
    private val h = Handler(Looper.getMainLooper())
    private var lastLog = ""
    private val tick = object : Runnable { override fun run() { refresh(false); h.postDelayed(this, 1000) } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = bg; window.navigationBarColor = bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(20), dp(36), dp(20), dp(12))
        }
        root.addView(TextView(this).apply {
            text = "←  診断"; setTextColor(Color.WHITE); textSize = 20f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(4), 0, dp(12)); setOnClickListener { finish() }
        })
        checkV = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; setPadding(0, 0, 0, dp(10)) }
        root.addView(checkV)
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btns.addView(btn("ログをコピー") { copyAll() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(8) })
        btns.addView(btn("ログを消す") { Dbg.clear(); refresh(true) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(btns)
        logV = TextView(this).apply {
            setTextColor(0xFF9CA3AF.toInt()); textSize = 11f; typeface = Typeface.MONOSPACE; setPadding(0, dp(10), 0, 0)
            setTextIsSelectable(true)
        }
        scroll = ScrollView(this).apply { addView(logV) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun btn(label: String, click: () -> Unit) = Button(this).apply {
        text = label; setTextColor(Color.WHITE); isAllCaps = false; textSize = 14f
        background = GradientDrawable().apply { setColor(0xFF374151.toInt()); cornerRadius = dp(22).toFloat() }
        setOnClickListener { click() }
    }

    private fun ok(v: Boolean) = if (v) "✓" else "✗"

    private fun checks(): String {
        val nfc = NfcAdapter.getDefaultAdapter(this)
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val wifiPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.NEARBY_WIFI_DEVICES else Manifest.permission.ACCESS_FINE_LOCATION
        val sb = StringBuilder()
        sb.append("端末: ${Build.MANUFACTURER} ${Build.MODEL} / Android ${Build.VERSION.RELEASE}\n")
        sb.append("NFC: ").append(when { nfc == null -> "非対応 ✗"; nfc.isEnabled -> "オン ✓"; else -> "オフ ✗" }).append('\n')
        sb.append("カードエミュレーション(送信に必要): ")
            .append(ok(packageManager.hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION))).append('\n')
        sb.append("Wi-Fi: ${if (wm.isWifiEnabled) "オン ✓" else "オフ ✗"}  IP: ${Net.localIps().ifEmpty { listOf("なし") }.joinToString()}\n")
        sb.append("Wi-Fi Direct対応: ${ok(packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT))}  ")
        sb.append("権限: ${ok(checkSelfPermission(wifiPerm) == PackageManager.PERMISSION_GRANTED)}")
        if (Build.VERSION.SDK_INT >= 33)
            sb.append("  通知: ${ok(checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)}")
        sb.append("\n送信中: ${TransferService.sending}  受信中: ${TransferService.receiving}")
        return sb.toString()
    }

    private fun refresh(forceScroll: Boolean) {
        checkV.text = checks()
        val log = Dbg.dump()
        if (log != lastLog || forceScroll) {
            lastLog = log
            logV.text = if (log.isEmpty()) "(ログはまだありません)" else log
            scroll.post { scroll.fullScroll(android.view.View.FOCUS_DOWN) }
        }
    }

    private fun copyAll() {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("TapShare log", checks() + "\n\n" + Dbg.dump()))
        Toast.makeText(this, "コピーしました", Toast.LENGTH_SHORT).show()
    }
}
