package dora.taptoshare

import android.annotation.SuppressLint
import android.content.Context
import android.net.*
import android.net.wifi.WifiNetworkSpecifier
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

typealias Opener = (String) -> HttpURLConnection

object Net {

    /** 自分のローカルIPv4(Wi-Fi・テザリング等)。モバイル回線とWi-Fi Direct用IFは除く。 */
    fun localIps(): List<String> {
        val out = ArrayList<String>()
        try {
            val all = NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList()
            for (ni in all) {
                if (!ni.isUp || ni.isLoopback) continue
                val n = ni.name.lowercase()
                if (n.startsWith("p2p") || n.startsWith("rmnet") || n.startsWith("ccmni") ||
                    n.startsWith("tun") || n.startsWith("dummy") || n.startsWith("v4-")) continue
                for (a in ni.inetAddresses.toList()) {
                    if (a is Inet4Address && !a.isLoopbackAddress && a.isSiteLocalAddress) a.hostAddress?.let { out.add(it) }
                }
            }
        } catch (_: Exception) {}
        return out
    }

    private fun http(url: URL, net: Network?, connect: Int, read: Int): HttpURLConnection {
        val c = (net?.openConnection(url) ?: url.openConnection()) as HttpURLConnection
        c.connectTimeout = connect; c.readTimeout = read
        return c
    }

    /** まず同一Wi-Fi(LAN)の各IPを試し、だめならWi-Fi Directグループへ参加する。 */
    fun connect(ctx: Context, o: JSONObject): Opener {
        val t = o.getString("t"); val port = o.getInt("p")
        val ips = ArrayList<String>()
        o.optJSONArray("ips")?.let { for (i in 0 until it.length()) ips.add(it.getString(i)) }
        Dbg.d("接続情報: ips=$ips port=$port Wi-Fi Direct=${if (o.optString("s").isEmpty()) "なし" else o.optString("s")}")
        val errs = ArrayList<String>()
        for (ip in ips) {
            try {
                Dbg.d("LAN試行 $ip:$port")
                val c = http(URL("http://$ip:$port/$t/manifest"), null, 2000, 3000)
                if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
                c.inputStream.close()
                Dbg.d("LAN成功 $ip")
                return { path -> http(URL("http://$ip:$port/$t/$path"), null, 5000, 20000) }
            } catch (e: Exception) {
                Dbg.d("LAN失敗 $ip: ${e.javaClass.simpleName} ${e.message}")
                errs.add("$ip: ${e.message}")
            }
        }
        val ssid = o.optString("s")
        if (ssid.isEmpty()) {
            throw IOException(
                if (ips.isEmpty()) "相手のIPがなく、Wi-Fi Directも使えませんでした。相手のWi-FiをオンにするかWi-Fi Directを許可してください"
                else "同じWi-Fiにつながっていないようです(${errs.firstOrNull()})。両方を同じWi-Fiにするか、Wi-Fi Directを許可してください"
            )
        }
        Dbg.d("Wi-Fi Direct参加を試行 $ssid")
        val net = joinGroup(ctx, ssid, o.getString("k"))
        val host = o.optString("g", "192.168.49.1")
        Dbg.d("Wi-Fi Direct参加OK → $host:$port")
        return { path -> http(URL("http://$host:$port/$t/$path"), net, 8000, 20000) }
    }

    private fun joinGroup(ctx: Context, ssid: String, pass: String): Network {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val spec = WifiNetworkSpecifier.Builder().setSsid(ssid).setWpa2Passphrase(pass).build()
        val req = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .setNetworkSpecifier(spec).build()
        val latch = CountDownLatch(1)
        var found: Network? = null
        cm.requestNetwork(req, object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { Dbg.d("Wi-Fi Direct: onAvailable"); found = network; latch.countDown() }
            override fun onUnavailable() { Dbg.d("Wi-Fi Direct: onUnavailable(拒否/見つからず)"); latch.countDown() }
        }, 25000)
        latch.await(27, TimeUnit.SECONDS)
        return found ?: throw IOException("Wi-Fi Directに接続できませんでした(接続の確認ダイアログを許可してください)")
    }
}

/** 送信側: Wi-Fi Directグループ(SSID/パスフレーズ固定)を作る。 */
class P2pGroup(private val ctx: Context) {
    private val mgr = ctx.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
    private var ch: WifiP2pManager.Channel? = null

    private fun rnd(n: Int): String {
        val cs = "abcdefghijkmnpqrstuvwxyz23456789"
        return (1..n).map { cs.random() }.joinToString("")
    }

    private fun reason(r: Int) = when (r) {
        WifiP2pManager.P2P_UNSUPPORTED -> "P2P非対応"
        WifiP2pManager.BUSY -> "使用中(BUSY)"
        WifiP2pManager.ERROR -> "エラー"
        else -> "コード$r"
    }

    @SuppressLint("MissingPermission")
    fun create(cb: (ssid: String?, pass: String?) -> Unit) {
        try {
            val channel = mgr.initialize(ctx, ctx.mainLooper, null)
            if (channel == null) { Dbg.d("P2P: initialize失敗"); cb(null, null); return }
            ch = channel
            val ssid = "DIRECT-ts-" + rnd(4); val pass = rnd(10)
            val cfg = WifiP2pConfig.Builder().setNetworkName(ssid).setPassphrase(pass).build()
            val go = {
                mgr.createGroup(channel, cfg, object : WifiP2pManager.ActionListener {
                    override fun onSuccess() = cb(ssid, pass)
                    override fun onFailure(reason: Int) { Dbg.d("P2P: createGroup失敗 ${reason(reason)}"); cb(null, null) }
                })
            }
            mgr.removeGroup(channel, object : WifiP2pManager.ActionListener {
                override fun onSuccess() { go() }
                override fun onFailure(reason: Int) { go() }
            })
        } catch (e: Exception) {
            Dbg.d("P2P: 例外 ${e.javaClass.simpleName} ${e.message}(権限がない可能性)")
            cb(null, null)
        }
    }

    @SuppressLint("MissingPermission")
    fun remove() { try { ch?.let { mgr.removeGroup(it, null) } } catch (_: Exception) {} }
}
