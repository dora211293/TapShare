package dora.taptoshare

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class SettingsActivity : Activity() {
    private val bg = 0xFF0B1020.toInt()
    private lateinit var col: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = bg; window.navigationBarColor = bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(bg)
            setPadding(dp(20), dp(36), dp(20), dp(12))
        }
        root.addView(TextView(this).apply {
            text = "←  設定"; setTextColor(Color.WHITE); textSize = 20f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(4), 0, dp(16)); setOnClickListener { finish() }
        })
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(col) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        build()
    }

    private fun build() {
        col.removeAllViews()
        switchRow("バックグラウンド待機",
            "アプリを閉じていても、画面をつけた状態でかざすと自動で受信します", Prefs.bg(this)) { Prefs.setBg(this, it) }
        val m = Prefs.autoStop(this)
        clickRow("送信待機の自動停止", if (m == 0) "なし(手動で停止)" else "${m}分で自動停止") { pickAutoStop() }
        switchRow("Wi-Fi Directを使う",
            "同じWi-Fiにいない相手にも送れます(オフならWi-Fi経由のみ)", Prefs.p2p(this)) { Prefs.setP2p(this, it) }
        switchRow("振動", "かざした時と完了時に振動します", Prefs.vibrate(this)) { Prefs.setVibrate(this, it) }
        clickRow("保存先フォルダ", "Download/${Prefs.folder(this)}") { editFolder() }
        clickRow("通知の設定", "転送中・完了通知の表示を変更") {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
        clickRow("診断ログ", "つながらない時の原因確認・ログのコピー") { startActivity(Intent(this, DebugActivity::class.java)) }
        col.addView(TextView(this).apply {
            text = "Tap Share 1.1.1"; setTextColor(0xFF4B5563.toInt()); textSize = 12f; gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(16))
        })
    }

    private fun row(title: String, sub: String, right: View?, click: () -> Unit) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply { setColor(0xFF151B2E.toInt()); cornerRadius = dp(16).toFloat() }
            setOnClickListener { click() }
        }
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        t.addView(TextView(this).apply { text = title; setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD })
        t.addView(TextView(this).apply { text = sub; setTextColor(0xFF9CA3AF.toInt()); textSize = 12f; setPadding(0, dp(2), 0, 0) })
        r.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        right?.let { r.addView(it) }
        col.addView(r, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }

    private fun switchRow(title: String, sub: String, on: Boolean, change: (Boolean) -> Unit) {
        val sw = Switch(this).apply { isChecked = on; setOnCheckedChangeListener { _, c -> change(c) } }
        row(title, sub, sw) { sw.toggle() }
    }

    private fun clickRow(title: String, sub: String, click: () -> Unit) = row(title, sub, null, click)

    private fun pickAutoStop() {
        val values = intArrayOf(0, 5, 10, 30, 60)
        val labels = arrayOf("なし", "5分", "10分", "30分", "60分")
        val cur = values.indexOf(Prefs.autoStop(this)).coerceAtLeast(0)
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("送信待機の自動停止")
            .setSingleChoiceItems(labels, cur) { d, w -> Prefs.setAutoStop(this, values[w]); d.dismiss(); build() }
            .show()
    }

    private fun editFolder() {
        val et = EditText(this).apply { setText(Prefs.folder(this@SettingsActivity)); setSingleLine() }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("保存先フォルダ名 (Download配下)")
            .setView(et)
            .setPositiveButton("保存") { _, _ -> Prefs.setFolder(this, et.text.toString()); build() }
            .setNegativeButton("キャンセル", null)
            .show()
    }
}
