package dora.taptoshare

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import org.json.JSONArray
import org.json.JSONObject

/** サービスと画面の間で状態を共有する。 */
object Hub {
    const val IDLE = 0; const val SEND = 1; const val RECV = 2; const val DONE = 3; const val ERR = 4
    data class UiState(val title: String, val sub: String, val mode: Int, val progress: Float = -1f)

    @Volatile var state = UiState("受信待機中", "送る側のスマホにかざしてください", IDLE)
    @Volatile var items: List<Item> = emptyList()
    @Volatile var listener: (() -> Unit)? = null
    private val h = Handler(Looper.getMainLooper())
    fun post(s: UiState) { state = s; h.post { listener?.invoke() } }

    /** エラーなどを数秒だけ表示して、待機表示に戻す */
    fun flash(s: UiState, ms: Long = 3500) {
        post(s)
        h.postDelayed({ if (state === s) post(UiState("受信待機中", "送る側のスマホにかざしてください", IDLE)) }, ms)
    }
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun bg(c: Context) = sp(c).getBoolean("bg", true)
    fun setBg(c: Context, v: Boolean) { sp(c).edit().putBoolean("bg", v).apply(); applyBg(c) }

    fun vibrate(c: Context) = sp(c).getBoolean("vibrate", true)
    fun setVibrate(c: Context, v: Boolean) = sp(c).edit().putBoolean("vibrate", v).apply()

    fun p2p(c: Context) = sp(c).getBoolean("p2p", true)
    fun setP2p(c: Context, v: Boolean) = sp(c).edit().putBoolean("p2p", v).apply()

    fun autoStop(c: Context) = sp(c).getInt("autostop", 10)
    fun setAutoStop(c: Context, v: Int) = sp(c).edit().putInt("autostop", v).apply()

    fun folder(c: Context): String = sp(c).getString("folder", "TapShare") ?: "TapShare"
    fun setFolder(c: Context, v: String) {
        val clean = v.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").ifEmpty { "TapShare" }
        sp(c).edit().putString("folder", clean).apply()
    }

    /** バックグラウンド待機 = NDEF_DISCOVERED を受ける画面を有効/無効にする */
    fun applyBg(c: Context) {
        c.packageManager.setComponentEnabledSetting(
            ComponentName(c, TapReceiveActivity::class.java),
            if (bg(c)) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
    }
}

object History {
    data class Row(val dir: String, val name: String, val size: Long, val time: Long, val uri: String?, val mime: String)

    private fun sp(c: Context) = c.getSharedPreferences("hist", Context.MODE_PRIVATE)

    @Synchronized fun add(c: Context, r: Row) {
        val old = JSONArray(sp(c).getString("rows", "[]"))
        val out = JSONArray()
        out.put(JSONObject().put("d", r.dir).put("n", r.name).put("s", r.size)
            .put("t", r.time).put("u", r.uri ?: "").put("m", r.mime))
        for (i in 0 until minOf(old.length(), 99)) out.put(old.get(i))
        sp(c).edit().putString("rows", out.toString()).apply()
    }

    fun all(c: Context): List<Row> {
        val a = JSONArray(sp(c).getString("rows", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Row(o.getString("d"), o.getString("n"), o.getLong("s"), o.getLong("t"),
                o.optString("u").ifEmpty { null }, o.optString("m"))
        }
    }

    fun clear(c: Context) { sp(c).edit().clear().apply() }
}

fun buzz(c: Context) {
    if (!Prefs.vibrate(c)) return
    try { c.getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(60, 255)) } catch (_: Exception) {}
}

fun fmtSize(b: Long): String = when {
    b < 0 -> "?"
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> "${b / 1024} KB"
    b < 1024L * 1024 * 1024 -> String.format("%.1f MB", b / 1048576.0)
    else -> String.format("%.2f GB", b / 1073741824.0)
}
