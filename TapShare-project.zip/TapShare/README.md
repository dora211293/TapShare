# Tap Share
スマホをかざすだけでファイルを送るAndroidアプリ(NFC + Wi-Fi/Wi-Fi Direct)

## 使い方(1.1.0)
- 送る側: アプリで「ファイルを選んで送る」(または他アプリの共有メニューから Tap Share) → 相手にかざす
- 受ける側: アプリを開いて待機 → 送る側にかざす。Download/TapShare に保存されます

## APKのビルド
### A. GitHub Actions(PCなしでOK)
1. このフォルダをGitHubの新規リポジトリにpush
2. Actions タブ → build-apk → 完了後 Artifacts の TapShare-debug-apk をDL
### B. Android Studio
フォルダを開いて Build > Build APK(s)

## 1.1.0 の追加機能
- バックグラウンド待機(設定でON\/OFF): アプリを閉じていても、画面をつけてかざすと自動受信
- 送信・受信をフォアグラウンドサービス化(アプリを閉じても転送が続く、通知に進捗)
- 履歴画面(受信ファイルはタップで開ける)
- 設定: 送信待機の自動停止 / Wi-Fi Direct ON\/OFF / 振動 / 保存先フォルダ名
- 写真・動画だけ選ぶボタン、送信完了後に別の端末へ続けて送信
