# Tap Share
スマホをかざすだけでファイルを送るAndroidアプリ(NFC + Wi-Fi/Wi-Fi Direct)

## 使い方
- 送る側: アプリで「ファイルを選んで送る」(または他アプリの共有メニューから Tap Share) → 相手にかざす
- 受ける側: アプリを開いて待機 → 送る側にかざす。Download/TapShare に保存されます

## APKのビルド
### A. GitHub Actions(PCなしでOK)
1. このフォルダをGitHubの新規リポジトリにpush
2. Actions タブ → build-apk → 完了後 Artifacts の TapShare-debug-apk をDL
### B. Android Studio
フォルダを開いて Build > Build APK(s)
