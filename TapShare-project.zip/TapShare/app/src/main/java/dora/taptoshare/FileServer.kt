package dora.taptoshare

import android.content.ContentResolver
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

data class Item(val uri: Uri, val name: String, val size: Long, val mime: String)

/** 送信側の簡易HTTPサーバ。/<token>/manifest と /<token>/file/<n> を配信。 */
class FileServer(
    private val cr: ContentResolver,
    private val items: List<Item>,
    val token: String,
    private val onProgress: (sent: Long, total: Long) -> Unit
) {
    private val ss = ServerSocket(0)
    val port: Int get() = ss.localPort
    private val sent = AtomicLong(0)
    private val total = items.sumOf { maxOf(it.size, 0L) }

    fun start() {
        thread(isDaemon = true) {
            while (!ss.isClosed) {
                val s = try { ss.accept() } catch (e: Exception) { break }
                thread(isDaemon = true) { try { handle(s) } catch (_: Exception) {} }
            }
        }
    }

    fun reset() { sent.set(0) }

    fun stop() { try { ss.close() } catch (_: Exception) {} }

    private fun handle(s: Socket) = s.use {
        val reader = s.getInputStream().bufferedReader()
        val line = reader.readLine() ?: return@use
        while (true) { val l = reader.readLine() ?: break; if (l.isEmpty()) break }
        val path = line.split(" ").getOrNull(1) ?: return@use
        val seg = path.trim('/').split('/')
        val out = s.getOutputStream()
        if (seg.size < 2 || seg[0] != token) { reply(out, 403, "text/plain", "forbidden".toByteArray()); return@use }
        when (seg[1]) {
            "manifest" -> {
                val arr = JSONArray()
                items.forEach { arr.put(JSONObject().put("name", it.name).put("size", it.size).put("mime", it.mime)) }
                reply(out, 200, "application/json", JSONObject().put("files", arr).toString().toByteArray())
            }
            "file" -> {
                val it = items.getOrNull(seg.getOrNull(2)?.toIntOrNull() ?: -1)
                if (it == null) { reply(out, 404, "text/plain", "not found".toByteArray()); return@use }
                val head = StringBuilder("HTTP/1.1 200 OK\r\nContent-Type: ${it.mime}\r\nConnection: close\r\n")
                if (it.size >= 0) head.append("Content-Length: ${it.size}\r\n")
                head.append("\r\n")
                out.write(head.toString().toByteArray())
                cr.openInputStream(it.uri)?.use { ins ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf); if (n < 0) break
                        out.write(buf, 0, n)
                        onProgress(sent.addAndGet(n.toLong()), total)
                    }
                }
                out.flush()
            }
            else -> reply(out, 404, "text/plain", "not found".toByteArray())
        }
    }

    private fun reply(out: OutputStream, code: Int, type: String, body: ByteArray) {
        out.write("HTTP/1.1 $code X\r\nContent-Type: $type\r\nContent-Length: ${body.size}\r\nConnection: close\r\n\r\n".toByteArray())
        out.write(body); out.flush()
    }
}
