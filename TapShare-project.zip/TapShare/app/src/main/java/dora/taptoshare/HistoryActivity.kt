package dora.taptoshare

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : Activity() {
    private val bg = 0xFF0B1020.toInt()
    private lateinit var col: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = bg; window.navigationBarColor = bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(bg)
            setPadding(dp(20), dp(36), dp(20), dp(12))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply {
            text = "←  履歴"; setTextColor(Color.WHITE); textSize = 20f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(4), 0, dp(16)); setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(TextView(this).apply {
            text = "全削除"; setTextColor(0xFFF87171.toInt()); textSize = 14f; setPadding(dp(8), dp(4), 0, dp(16))
            setOnClickListener { History.clear(this@HistoryActivity); build() }
        })
        root.addView(top)
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(col) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        build()
    }

    private fun build() {
        col.removeAllViews()
        val rows = History.all(this)
        if (rows.isEmpty()) {
            col.addView(TextView(this).apply {
                text = "まだ履歴がありません"; setTextColor(0xFF6B7280.toInt()); gravity = Gravity.CENTER
                setPadding(0, dp(60), 0, 0)
            })
            return
        }
        val df = SimpleDateFormat("M/d HH:mm", Locale.JAPAN)
        for (r in rows) {
            val v = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12))
                background = GradientDrawable().apply { setColor(0xFF151B2E.toInt()); cornerRadius = dp(16).toFloat() }
            }
            val recv = r.dir == "recv"
            v.addView(TextView(this).apply { text = r.name; setTextColor(Color.WHITE); textSize = 15f; maxLines = 1 })
            v.addView(TextView(this).apply {
                text = "${if (recv) "↓ 受信" else "↑ 送信"}  ·  ${fmtSize(r.size)}  ·  ${df.format(Date(r.time))}"
                setTextColor(if (recv) 0xFF4DE1FF.toInt() else 0xFF8B5CF6.toInt()); textSize = 12f; setPadding(0, dp(2), 0, 0)
            })
            if (recv && r.uri != null) v.setOnClickListener { open(r) }
            col.addView(v, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
    }

    private fun open(r: History.Row) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(r.uri), r.mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "開けるアプリがありません", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "ファイルが見つかりません", Toast.LENGTH_SHORT).show()
        }
    }
}
