package dora.taptoshare

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*

class MainActivity : Activity(), NfcAdapter.ReaderCallback {

    private val bg = 0xFF0B1020.toInt()
    private val cyan = 0xFF4DE1FF.toInt()
    private val violet = 0xFF8B5CF6.toInt()
    private val green = 0xFF34D399.toInt()
    private val red = 0xFFF87171.toInt()

    private lateinit var pulse: PulseView
    private lateinit var titleV: TextView
    private lateinit var subV: TextView
    private lateinit var listV: TextView
    private lateinit var bar: ProgressBar
    private lateinit var stopBtn: Button

    private var nfc: NfcAdapter? = null
    private var readerOn = false
    private var lastTap = 0L

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = bg; window.navigationBarColor = bg
        nfc = NfcAdapter.getDefaultAdapter(this)
        Prefs.applyBg(this)
        buildUi()
        requestPerms()
        handleIntent(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handleIntent(i) }

    override fun onResume() {
        super.onResume()
        Hub.listener = { render() }
        render()
    }

    override fun onPause() {
        super.onPause()
        Hub.listener = null
        setReader(false)
    }

    // ---------- UI ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(bg)
            setPadding(dp(24), dp(36), dp(24), dp(24))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply {
            text = "TAP SHARE"; setTextColor(cyan); textSize = 14f; letterSpacing = 0.3f; typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(link("履歴") { startActivity(Intent(this, HistoryActivity::class.java)) })
        top.addView(link("設定") { startActivity(Intent(this, SettingsActivity::class.java)) })
        root.addView(top)

        pulse = PulseView(this)
        root.addView(pulse, LinearLayout.LayoutParams(-1, 0, 1f))

        titleV = TextView(this).apply {
            textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            setOnClickListener { if (nfc?.isEnabled == false) startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) }
        }
        subV = TextView(this).apply { textSize = 14f; setTextColor(0xFF9CA3AF.toInt()); gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(12)) }
        listV = TextView(this).apply { textSize = 12f; setTextColor(0xFF6B7280.toInt()); gravity = Gravity.CENTER; maxLines = 4 }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        root.addView(titleV, LinearLayout.LayoutParams(-1, -2))
        root.addView(subV, LinearLayout.LayoutParams(-1, -2))
        root.addView(bar, LinearLayout.LayoutParams(-1, dp(8)).apply { setMargins(0, 0, 0, dp(12)) })
        root.addView(listV, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(16)) })

        root.addView(pill("ファイルを選んで送る", violet) { pick(false) }, LinearLayout.LayoutParams(-1, dp(56)))
        root.addView(pill("写真・動画を選んで送る", 0xFF1F2937.toInt()) { pick(true) },
            LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        stopBtn = pill("送信をやめる", 0xFF374151.toInt()) { TransferService.stop(this) }
        root.addView(stopBtn, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        setContentView(root)
    }

    private fun link(label: String, click: () -> Unit) = TextView(this).apply {
        text = label; setTextColor(0xFFCBD5E1.toInt()); textSize = 14f
        setPadding(dp(12), dp(8), dp(4), dp(8)); setOnClickListener { click() }
    }

    private fun pill(label: String, color: Int, click: () -> Unit) = Button(this).apply {
        text = label; setTextColor(Color.WHITE); isAllCaps = false; textSize = 16f
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(28).toFloat() }
        setOnClickListener { click() }
    }

    private fun colorOf(mode: Int) = when (mode) {
        Hub.SEND -> violet; Hub.DONE -> green; Hub.ERR -> red; else -> cyan
    }

    private fun render() {
        val a = nfc
        var s = Hub.state
        if (a == null) s = Hub.UiState("NFC非対応", "この端末ではNFCが使えません", Hub.ERR)
        else if (!a.isEnabled) s = Hub.UiState("NFCがオフです", "ここをタップして設定を開く", Hub.ERR)
        titleV.text = s.title; subV.text = s.sub
        val c = colorOf(s.mode)
        pulse.accent = c
        bar.progressTintList = android.content.res.ColorStateList.valueOf(c)
        bar.progress = if (s.progress < 0) 0 else (s.progress * 1000).toInt()
        stopBtn.visibility = if (TransferService.sending) View.VISIBLE else View.GONE
        listV.text = Hub.items.joinToString("\n") { "${it.name}  (${fmtSize(it.size)})" }
        setReader(!TransferService.sending && a?.isEnabled == true)
    }

    private fun setReader(on: Boolean) {
        val a = nfc ?: return
        if (on == readerOn) return
        try {
            if (on) a.enableReaderMode(this, this, NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B, null)
            else a.disableReaderMode(this)
            readerOn = on
        } catch (_: Exception) {}
    }

    private fun requestPerms() {
        val p = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        requestPermissions(p, 1)
    }

    // ---------- 送信 ----------
    private fun pick(mediaOnly: Boolean) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            if (mediaOnly) putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
        }
        startActivityForResult(i, 10)
    }

    @Deprecated("simple")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 10 || res != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { for (i in 0 until it.itemCount) uris.add(it.getItemAt(i).uri) }
        data.data?.let { if (uris.isEmpty()) uris.add(it) }
        TransferService.send(this, uris)
    }

    @Suppress("DEPRECATION")
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val uris = mutableListOf<Uri>()
        when (i.action) {
            Intent.ACTION_SEND -> (i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))?.let { uris.add(it) }
            Intent.ACTION_SEND_MULTIPLE -> i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { uris.addAll(it) }
        }
        if (uris.isNotEmpty()) {
            TransferService.send(this, uris)
            i.action = null
        }
    }

    // ---------- 受信(アプリを開いている間) ----------
    override fun onTagDiscovered(tag: Tag) {
        val now = SystemClock.elapsedRealtime()
        if (TransferService.receiving || now - lastTap < 1500) return
        lastTap = now
        try {
            val ndef = Ndef.get(tag) ?: return
            ndef.connect()
            val msg = ndef.cachedNdefMessage ?: ndef.ndefMessage
            ndef.close()
            val rec = msg?.records?.firstOrNull { String(it.type) == TapHceService.MIME } ?: return
            buzz(this)
            TransferService.recv(this, String(rec.payload))
        } catch (_: Exception) {}
    }
}
