package dora.taptoshare

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.*
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : Activity(), NfcAdapter.ReaderCallback {

    private val bg = 0xFF0B1020.toInt()
    private val cyan = 0xFF4DE1FF.toInt()
    private val violet = 0xFF8B5CF6.toInt()
    private val green = 0xFF34D399.toInt()
    private val red = 0xFFF87171.toInt()

    private lateinit var pulse: PulseView
    private lateinit var titleV: TextView
    private lateinit var subV: TextView
    private lateinit var listV: TextView
    private lateinit var bar: ProgressBar
    private lateinit var pickBtn: Button
    private lateinit var stopBtn: Button

    private var nfc: NfcAdapter? = null
    private var server: FileServer? = null
    private var p2p: P2pGroup? = null
    private var items: List<Item> = emptyList()
    private var busy = false
    private var lastTap = 0L
    private val ui = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = bg; window.navigationBarColor = bg
        nfc = NfcAdapter.getDefaultAdapter(this)
        buildUi()
        requestPerms()
        handleIntent(intent)
        refresh()
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handleIntent(i) }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(bg)
            setPadding(dp(24), dp(40), dp(24), dp(24))
        }
        root.addView(TextView(this).apply {
            text = "TAP SHARE"; setTextColor(cyan); textSize = 14f; letterSpacing = 0.3f
            typeface = Typeface.DEFAULT_BOLD
        })
        pulse = PulseView(this)
        root.addView(pulse, LinearLayout.LayoutParams(-1, 0, 1f))
        titleV = TextView(this).apply { textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD }
        subV = TextView(this).apply { textSize = 14f; setTextColor(0xFF9CA3AF.toInt()); gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(12)) }
        listV = TextView(this).apply { textSize = 12f; setTextColor(0xFF6B7280.toInt()); gravity = Gravity.CENTER; maxLines = 4 }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000; progressTintList = android.content.res.ColorStateList.valueOf(cyan)
        }
        root.addView(titleV, LinearLayout.LayoutParams(-1, -2))
        root.addView(subV, LinearLayout.LayoutParams(-1, -2))
        root.addView(bar, LinearLayout.LayoutParams(-1, dp(8)).apply { setMargins(0, 0, 0, dp(12)) })
        root.addView(listV, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(16)) })
        pickBtn = pill("ファイルを選んで送る", violet) { pick() }
        stopBtn = pill("送信をやめる", 0xFF374151.toInt()) { stopSending() }
        root.addView(pickBtn, LinearLayout.LayoutParams(-1, dp(56)))
        root.addView(stopBtn, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        setContentView(root)
    }

    private fun pill(label: String, color: Int, click: () -> Unit) = Button(this).apply {
        text = label; setTextColor(Color.WHITE); isAllCaps = false; textSize = 16f
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(28).toFloat() }
        setOnClickListener { click() }
    }

    private fun requestPerms() {
        val p = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        requestPermissions(p, 1)
    }

    // ---------- 状態表示 ----------
    private fun status(title: String, sub: String, color: Int = cyan, progress: Float = -1f) = ui.post {
        titleV.text = title; subV.text = sub; pulse.accent = color
        bar.progressTintList = android.content.res.ColorStateList.valueOf(color)
        bar.progress = if (progress < 0) 0 else (progress * 1000).toInt()
    }

    private fun refresh() {
        val adapter = nfc
        stopBtn.visibility = if (items.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE
        listV.text = items.joinToString("\n") { "${it.name}  (${fmt(it.size)})" }
        if (adapter == null) { status("NFC非対応", "この端末ではNFCが使えません", red); return }
        if (!adapter.isEnabled) {
            status("NFCがオフです", "タップして設定を開く", red)
            titleV.setOnClickListener { startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) }
            return
        }
        if (items.isEmpty()) {
            setReader(true)
            status("受信待機中", "送る側のスマホにかざしてください", cyan)
        } else {
            setReader(false)
            status("かざして送信", "${items.size}件を準備しました。相手のスマホにかざしてください", violet)
        }
    }

    private fun setReader(on: Boolean) {
        val a = nfc ?: return
        try {
            if (on) a.enableReaderMode(this, this, NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B, null)
            else a.disableReaderMode(this)
        } catch (_: Exception) {}
    }

    override fun onResume() { super.onResume(); refresh() }
    override fun onPause() { super.onPause(); setReader(false) }
    override fun onDestroy() { stopSending(); super.onDestroy() }

    // ---------- 送信側 ----------
    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(i, 10)
    }

    @Deprecated("simple")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 10 || res != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { for (i in 0 until it.itemCount) uris.add(it.getItemAt(i).uri) }
        data.data?.let { if (uris.isEmpty()) uris.add(it) }
        startSending(uris)
    }

    @Suppress("DEPRECATION")
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val uris = mutableListOf<Uri>()
        when (i.action) {
            Intent.ACTION_SEND -> (i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))?.let { uris.add(it) }
            Intent.ACTION_SEND_MULTIPLE -> i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { uris.addAll(it) }
        }
        if (uris.isNotEmpty()) startSending(uris)
    }

    private fun startSending(uris: List<Uri>) {
        stopSending()
        items = uris.map { u ->
            var name = "file"; var size = -1L
            contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { name = c.getString(it) }
                    c.getColumnIndex(OpenableColumns.SIZE).takeIf { it >= 0 }?.let { size = c.getLong(it) }
                }
            }
            Item(u, name, size, contentResolver.getType(u) ?: "application/octet-stream")
        }
        val token = (1..8).map { "abcdefghijklmnopqrstuvwxyz0123456789".random() }.joinToString("")
        val s = FileServer(contentResolver, items, token) { sent, total ->
            val f = if (total > 0) sent.toFloat() / total else 0f
            if (total > 0 && sent >= total) status("送信完了 ✓", "相手に届きました", green, 1f)
            else status("送信中…", "${(f * 100).toInt()}%", violet, f)
        }
        s.start(); server = s
        val ip = Net.lanIp(this)
        fun publish(ssid: String?, pass: String?) {
            val o = JSONObject().put("v", 1).put("p", s.port).put("t", token)
            if (ip != null) o.put("ip", ip)
            if (ssid != null) o.put("s", ssid).put("k", pass).put("g", "192.168.49.1")
            TapHceService.setPayload(o.toString())
        }
        publish(null, null) // まずLAN情報だけ即時公開
        val g = P2pGroup(this); p2p = g
        g.create { ssid, pass -> if (server === s) publish(ssid, pass) }
        refresh()
    }

    private fun stopSending() {
        server?.stop(); server = null
        p2p?.remove(); p2p = null
        TapHceService.setPayload(null)
        items = emptyList()
        if (!isDestroyed) refresh()
    }

    // ---------- 受信側 ----------
    override fun onTagDiscovered(tag: Tag) {
        val now = SystemClock.elapsedRealtime()
        if (busy || now - lastTap < 1500) return
        lastTap = now
        try {
            val ndef = Ndef.get(tag) ?: return
            ndef.connect()
            val msg = ndef.cachedNdefMessage ?: ndef.ndefMessage
            ndef.close()
            val rec = msg?.records?.firstOrNull { String(it.type) == TapHceService.MIME } ?: return
            getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(60, 255))
            receive(String(rec.payload))
        } catch (_: Exception) {}
    }

    private fun receive(json: String) {
        busy = true
        thread {
            try {
                status("接続中…", "相手と接続しています", cyan)
                val open = Net.connect(this, JSONObject(json))
                val manifest = open("manifest").let { c -> c.inputStream.bufferedReader().readText() }
                val files = JSONObject(manifest).getJSONArray("files")
                var total = 0L; var done = 0L
                for (i in 0 until files.length()) total += maxOf(files.getJSONObject(i).getLong("size"), 0L)
                for (i in 0 until files.length()) {
                    val f = files.getJSONObject(i)
                    val name = f.getString("name")
                    val v = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, f.optString("mime", "application/octet-stream"))
                        put(MediaStore.Downloads.RELATIVE_PATH, "Download/TapShare")
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                        ?: throw java.io.IOException("保存先を作れませんでした")
                    val conn = open("file/$i")
                    conn.inputStream.use { ins ->
                        contentResolver.openOutputStream(uri)!!.use { out ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val n = ins.read(buf); if (n < 0) break
                                out.write(buf, 0, n); done += n
                                val p = if (total > 0) done.toFloat() / total else 0f
                                status("受信中… ${i + 1}/${files.length()}", "$name  ${(p * 100).toInt()}%", cyan, p)
                            }
                        }
                    }
                    v.clear(); v.put(MediaStore.Downloads.IS_PENDING, 0)
                    contentResolver.update(uri, v, null, null)
                }
                status("受信完了 ✓", "Download/TapShare に保存しました", green, 1f)
            } catch (e: Exception) {
                status("失敗しました", e.message ?: "もう一度かざしてください", red)
            } finally {
                busy = false
                ui.postDelayed({ if (!busy && items.isEmpty()) refresh() }, 4000)
            }
        }
    }

    private fun fmt(b: Long): String = when {
        b < 0 -> "?"
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> "${b / 1024} KB"
        b < 1024L * 1024 * 1024 -> String.format("%.1f MB", b / 1048576.0)
        else -> String.format("%.2f GB", b / 1073741824.0)
    }
}
