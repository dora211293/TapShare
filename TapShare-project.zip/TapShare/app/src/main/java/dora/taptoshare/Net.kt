package dora.taptoshare

import android.annotation.SuppressLint
import android.content.Context
import android.net.*
import android.net.wifi.WifiNetworkSpecifier
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

typealias Opener = (String) -> HttpURLConnection

object Net {

    fun lanIp(ctx: Context): String? {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val n = cm.activeNetwork ?: return null
        if (cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) != true) return null
        return cm.getLinkProperties(n)?.linkAddresses?.map { it.address }
            ?.firstOrNull { it is Inet4Address && !it.isLoopbackAddress }?.hostAddress
    }

    private fun http(url: URL, net: Network?, connect: Int, read: Int): HttpURLConnection {
        val c = (net?.openConnection(url) ?: url.openConnection()) as HttpURLConnection
        c.connectTimeout = connect; c.readTimeout = read
        return c
    }

    /** まず同一Wi-Fi(LAN)を試し、だめならWi-Fi Directグループへ参加する。 */
    fun connect(ctx: Context, o: JSONObject): Opener {
        val t = o.getString("t"); val port = o.getInt("p")
        val ip = o.optString("ip")
        if (ip.isNotEmpty()) {
            try {
                http(URL("http://$ip:$port/$t/manifest"), null, 2500, 3000).inputStream.close()
                return { path -> http(URL("http://$ip:$port/$t/$path"), null, 5000, 20000) }
            } catch (_: Exception) { /* P2Pへフォールバック */ }
        }
        val ssid = o.optString("s")
        if (ssid.isEmpty()) throw IOException("相手に接続できませんでした")
        val net = joinGroup(ctx, ssid, o.getString("k"))
        val host = o.optString("g", "192.168.49.1")
        return { path -> http(URL("http://$host:$port/$t/$path"), net, 8000, 20000) }
    }

    private fun joinGroup(ctx: Context, ssid: String, pass: String): Network {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val spec = WifiNetworkSpecifier.Builder().setSsid(ssid).setWpa2Passphrase(pass).build()
        val req = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .setNetworkSpecifier(spec).build()
        val latch = CountDownLatch(1)
        var found: Network? = null
        cm.requestNetwork(req, object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { found = network; latch.countDown() }
            override fun onUnavailable() { latch.countDown() }
        }, 25000)
        latch.await(27, TimeUnit.SECONDS)
        return found ?: throw IOException("Wi-Fi Directに接続できませんでした")
    }
}

/** 送信側: Wi-Fi Directグループ(SSID/パスフレーズ固定)を作る。 */
class P2pGroup(private val ctx: Context) {
    private val mgr = ctx.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
    private var ch: WifiP2pManager.Channel? = null

    private fun rnd(n: Int): String {
        val cs = "abcdefghijkmnpqrstuvwxyz23456789"
        return (1..n).map { cs.random() }.joinToString("")
    }

    @SuppressLint("MissingPermission")
    fun create(cb: (ssid: String?, pass: String?) -> Unit) {
        try {
            val channel = mgr.initialize(ctx, ctx.mainLooper, null); ch = channel
            val ssid = "DIRECT-ts-" + rnd(4); val pass = rnd(10)
            val cfg = WifiP2pConfig.Builder().setNetworkName(ssid).setPassphrase(pass).build()
            val go = {
                mgr.createGroup(channel, cfg, object : WifiP2pManager.ActionListener {
                    override fun onSuccess() = cb(ssid, pass)
                    override fun onFailure(reason: Int) = cb(null, null)
                })
            }
            mgr.removeGroup(channel, object : WifiP2pManager.ActionListener {
                override fun onSuccess() { go() }
                override fun onFailure(reason: Int) { go() }
            })
        } catch (e: Exception) { cb(null, null) }
    }

    @SuppressLint("MissingPermission")
    fun remove() { try { ch?.let { mgr.removeGroup(it, null) } } catch (_: Exception) {} }
}
