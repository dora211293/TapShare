package dora.taptoshare

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator

class PulseView(c: Context) : View(c) {
    var accent: Int = 0xFF4DE1FF.toInt()
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedFraction; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val m = minOf(width, height).toFloat()
        val r0 = m * 0.16f; val rmax = m * 0.46f
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f * resources.displayMetrics.density
        for (i in 0..2) {
            val f = (t + i / 3f) % 1f
            p.color = accent; p.alpha = ((1 - f) * 200).toInt()
            cv.drawCircle(cx, cy, r0 + (rmax - r0) * f, p)
        }
        p.style = Paint.Style.FILL; p.alpha = 255
        p.shader = RadialGradient(cx, cy, r0, accent, 0xFF8B5CF6.toInt(), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r0, p)
        p.shader = null
    }
}
