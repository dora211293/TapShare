package dora.taptoshare

import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.cardemulation.HostApduService
import android.os.Bundle

/** NFC Forum Type 4 Tag として振る舞い、接続情報(JSON)を NDEF で相手に渡す。 */
class TapHceService : HostApduService() {

    companion object {
        const val MIME = "application/vnd.dora.taptoshare"
        @Volatile var ndefFile: ByteArray = ByteArray(0)

        fun setPayload(json: String?) {
            ndefFile = if (json == null) ByteArray(0) else {
                val msg = NdefMessage(NdefRecord.createMime(MIME, json.toByteArray())).toByteArray()
                byteArrayOf((msg.size shr 8).toByte(), msg.size.toByte()) + msg
            }
        }

        private val AID = byteArrayOf(0xD2.toByte(), 0x76, 0x00, 0x00, 0x85.toByte(), 0x01, 0x01)
        private val CC = byteArrayOf(
            0x00, 0x0F, 0x20, 0x00, 0xFF.toByte(), 0x00, 0xFF.toByte(),
            0x04, 0x06, 0xE1.toByte(), 0x04, 0x04, 0x00, 0x00, 0xFF.toByte()
        )
        private val OK = byteArrayOf(0x90.toByte(), 0x00)
        private val NOT_FOUND = byteArrayOf(0x6A, 0x82.toByte())
        private val ERR = byteArrayOf(0x6F, 0x00)
    }

    private var selected = 0 // 1 = CC, 2 = NDEF

    override fun processCommandApdu(c: ByteArray, extras: Bundle?): ByteArray {
        if (c.size < 4) return ERR
        when (c[1].toInt() and 0xFF) {
            0xA4 -> { // SELECT
                if ((c[2].toInt() and 0xFF) == 0x04) {
                    val len = c[4].toInt() and 0xFF
                    if (c.size < 5 + len) return ERR
                    return if (c.copyOfRange(5, 5 + len).contentEquals(AID)) { selected = 0; OK } else NOT_FOUND
                }
                if (c.size < 7) return ERR
                val id = ((c[5].toInt() and 0xFF) shl 8) or (c[6].toInt() and 0xFF)
                return when {
                    id == 0xE103 -> { selected = 1; OK }
                    id == 0xE104 && ndefFile.isNotEmpty() -> { selected = 2; OK }
                    else -> NOT_FOUND
                }
            }
            0xB0 -> { // READ BINARY
                val data = when (selected) { 1 -> CC; 2 -> ndefFile; else -> return ERR }
                val off = ((c[2].toInt() and 0xFF) shl 8) or (c[3].toInt() and 0xFF)
                var le = if (c.size > 4) c[4].toInt() and 0xFF else 256
                if (le == 0) le = 256
                if (off > data.size) return ERR
                return data.copyOfRange(off, minOf(data.size, off + le)) + OK
            }
        }
        return ERR
    }

    override fun onDeactivated(reason: Int) { selected = 0 }
}
