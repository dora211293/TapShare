package dora.taptoshare

import android.app.Activity
import android.nfc.NdefMessage
import android.nfc.NfcAdapter
import android.os.Bundle
import android.widget.Toast

/** バックグラウンド待機: アプリが閉じていても、かざした瞬間にシステムから呼ばれて受信を始める。 */
class TapReceiveActivity : Activity() {
    @Suppress("DEPRECATION")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        try {
            val raw = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES)
            val msg = raw?.firstOrNull() as? NdefMessage
            val rec = msg?.records?.firstOrNull { String(it.type) == TapHceService.MIME }
            if (rec != null && !TransferService.receiving) {
                buzz(this)
                Toast.makeText(this, "受信を開始します", Toast.LENGTH_SHORT).show()
                TransferService.recv(this, String(rec.payload))
            }
        } catch (_: Exception) {}
        finish()
    }
}
