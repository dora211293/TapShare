package dora.taptoshare

import android.app.*
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.ContentValues
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.IOException
import kotlin.concurrent.thread

/** 送信待機・受信をバックグラウンドで続けるフォアグラウンドサービス。 */
class TransferService : Service() {

    companion object {
        const val A_SEND = "dora.taptoshare.SEND"
        const val A_RECV = "dora.taptoshare.RECV"
        const val A_STOP = "dora.taptoshare.STOP"
        private const val CH_RUN = "run"
        private const val CH_DONE = "done"
        private const val ID_FG = 1
        private const val ID_DONE = 2

        @Volatile var sending = false
        @Volatile var receiving = false

        fun send(ctx: Context, uris: List<Uri>) {
            if (uris.isEmpty()) return
            val cd = ClipData.newRawUri("files", uris[0])
            for (k in 1 until uris.size) cd.addItem(ClipData.Item(uris[k]))
            val i = Intent(ctx, TransferService::class.java).setAction(A_SEND)
            i.clipData = cd
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startForegroundService(i)
        }

        fun recv(ctx: Context, json: String) {
            ctx.startForegroundService(Intent(ctx, TransferService::class.java).setAction(A_RECV).putExtra("json", json))
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, TransferService::class.java).setAction(A_STOP))
        }
    }

    private lateinit var nm: NotificationManager
    private val h = Handler(Looper.getMainLooper())
    private var server: FileServer? = null
    private var p2p: P2pGroup? = null
    private var lastN = 0L
    private val autoStopRun = Runnable { clearSend(); finishIfIdle() }

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_RUN, "転送中", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "転送完了", NotificationManager.IMPORTANCE_DEFAULT))
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            A_SEND -> { fg("送信を準備中", "しばらくお待ちください"); startSend(i) }
            A_RECV -> { fg("受信を準備中", "相手と接続しています"); startRecv(i.getStringExtra("json") ?: "") }
            A_STOP -> { clearSend(); finishIfIdle() }
            else -> finishIfIdle()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() { clearSend(); super.onDestroy() }

    // ---------- 通知 ----------
    private fun fg(title: String, text: String, progress: Float = -1f) {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = Notification.Builder(this, CH_RUN)
            .setSmallIcon(if (receiving) android.R.drawable.stat_sys_download else android.R.drawable.stat_sys_upload)
            .setContentTitle(title).setContentText(text).setContentIntent(open).setOngoing(true)
        if (progress >= 0) b.setProgress(1000, (progress * 1000).toInt(), false)
        if (sending) {
            val stop = PendingIntent.getService(this, 1,
                Intent(this, TransferService::class.java).setAction(A_STOP), PendingIntent.FLAG_IMMUTABLE)
            b.addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "停止", stop).build())
        }
        startForeground(ID_FG, b.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }

    private fun notifyDone(title: String, text: String, rows: List<History.Row>) {
        val pi = if (rows.size == 1 && rows[0].uri != null) {
            val v = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(rows[0].uri), rows[0].mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            PendingIntent.getActivity(this, 2, v, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        } else {
            PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        }
        nm.notify(ID_DONE, Notification.Builder(this, CH_DONE)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(title).setContentText(text)
            .setContentIntent(pi).setAutoCancel(true).build())
    }

    // ---------- 共通 ----------
    private fun idleState() =
        if (sending) sendState() else Hub.UiState("受信待機中", "送る側のスマホにかざしてください", Hub.IDLE)

    private fun sendState() =
        Hub.UiState("かざして送信", "${Hub.items.size}件を準備しました。相手のスマホにかざしてください", Hub.SEND)

    private fun finishIfIdle() {
        if (!sending && !receiving) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    // ---------- 送信 ----------
    private fun startSend(i: Intent) {
        val uris = ArrayList<Uri>()
        i.clipData?.let { for (k in 0 until it.itemCount) uris.add(it.getItemAt(k).uri) }
        if (uris.isEmpty()) { finishIfIdle(); return }
        clearSend()

        val items = uris.map { u ->
            var name = "file"; var size = -1L
            try {
                contentResolver.query(u, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { name = c.getString(it) }
                        c.getColumnIndex(OpenableColumns.SIZE).takeIf { it >= 0 }?.let { size = c.getLong(it) }
                    }
                }
            } catch (_: Exception) {}
            Item(u, name, size, contentResolver.getType(u) ?: "application/octet-stream")
        }
        val token = (1..8).map { "abcdefghijklmnopqrstuvwxyz0123456789".random() }.joinToString("")
        val s = FileServer(contentResolver, items, token) { sent, total -> onSendProgress(sent, total) }
        s.start(); server = s
        Hub.items = items
        sending = true

        val ip = Net.lanIp(this)
        fun publish(ssid: String?, pass: String?) {
            val o = JSONObject().put("v", 1).put("p", s.port).put("t", token)
            if (ip != null) o.put("ip", ip)
            if (ssid != null) o.put("s", ssid).put("k", pass).put("g", "192.168.49.1")
            TapHceService.setPayload(o.toString())
        }
        publish(null, null)
        if (Prefs.p2p(this)) {
            val g = P2pGroup(this); p2p = g
            g.create { ssid, pass -> if (server === s) publish(ssid, pass) }
        }
        scheduleAutoStop()
        Hub.post(sendState())
        fg("かざして送信", "${items.size}件を待機中")
    }

    private fun scheduleAutoStop() {
        h.removeCallbacks(autoStopRun)
        val m = Prefs.autoStop(this)
        if (m > 0) h.postDelayed(autoStopRun, m * 60_000L)
    }

    private fun onSendProgress(sent: Long, total: Long) {
        scheduleAutoStop()
        val f = if (total > 0) sent.toFloat() / total else 0f
        if (total > 0 && sent >= total) {
            server?.reset()
            Hub.items.forEach {
                History.add(this, History.Row("send", it.name, it.size, System.currentTimeMillis(), null, it.mime))
            }
            buzz(this)
            Hub.post(Hub.UiState("送信完了 ✓", "続けて別の端末にもかざせます", Hub.DONE, 1f))
            fg("送信完了", "別の端末にもかざせます")
            h.postDelayed({ if (sending) Hub.post(sendState()) }, 4000)
            return
        }
        Hub.post(Hub.UiState("送信中…", "${(f * 100).toInt()}%", Hub.SEND, f))
        val now = SystemClock.elapsedRealtime()
        if (now - lastN > 500) { lastN = now; fg("送信中…", "${(f * 100).toInt()}%", f) }
    }

    private fun clearSend() {
        h.removeCallbacks(autoStopRun)
        server?.stop(); server = null
        p2p?.remove(); p2p = null
        TapHceService.setPayload(null)
        Hub.items = emptyList()
        if (sending) { sending = false; Hub.post(idleState()) }
    }

    // ---------- 受信 ----------
    private fun startRecv(json: String) {
        if (receiving || json.isEmpty()) { if (!receiving) finishIfIdle(); return }
        receiving = true
        thread {
            val saved = ArrayList<History.Row>()
            var cur: Uri? = null
            try {
                Hub.post(Hub.UiState("接続中…", "相手と接続しています", Hub.RECV))
                val open = Net.connect(this, JSONObject(json))
                val mc = open("manifest")
                if (mc.responseCode != 200) throw IOException("相手が応答しません (${mc.responseCode})")
                val files = JSONObject(mc.inputStream.bufferedReader().use { it.readText() }).getJSONArray("files")
                var total = 0L; var done = 0L
                for (i in 0 until files.length()) total += maxOf(files.getJSONObject(i).getLong("size"), 0L)
                val folder = Prefs.folder(this)

                for (i in 0 until files.length()) {
                    val f = files.getJSONObject(i)
                    val name = f.getString("name")
                    val mime = f.optString("mime", "application/octet-stream")
                    val v = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, mime)
                        put(MediaStore.Downloads.RELATIVE_PATH, "Download/$folder")
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                        ?: throw IOException("保存先を作れませんでした")
                    cur = uri
                    val conn = open("file/$i")
                    if (conn.responseCode != 200) throw IOException("ファイル取得エラー (${conn.responseCode})")
                    var last = 0L
                    conn.inputStream.use { ins ->
                        contentResolver.openOutputStream(uri)!!.use { out ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val n = ins.read(buf); if (n < 0) break
                                out.write(buf, 0, n); done += n
                                val p = if (total > 0) done.toFloat() / total else 0f
                                Hub.post(Hub.UiState("受信中… ${i + 1}/${files.length()}", "$name  ${(p * 100).toInt()}%", Hub.RECV, p))
                                val now = SystemClock.elapsedRealtime()
                                if (now - last > 500) { last = now; fg("受信中… ${i + 1}/${files.length()}", "$name  ${(p * 100).toInt()}%", p) }
                            }
                        }
                    }
                    v.clear(); v.put(MediaStore.Downloads.IS_PENDING, 0)
                    contentResolver.update(uri, v, null, null)
                    cur = null
                    saved.add(History.Row("recv", name, f.getLong("size"), System.currentTimeMillis(), uri.toString(), mime))
                }
                saved.forEach { History.add(this, it) }
                buzz(this)
                Hub.post(Hub.UiState("受信完了 ✓", "Download/$folder に保存しました", Hub.DONE, 1f))
                notifyDone("受信完了", "${saved.size}件を Download/$folder に保存しました", saved)
            } catch (e: Exception) {
                cur?.let { try { contentResolver.delete(it, null, null) } catch (_: Exception) {} }
                Hub.post(Hub.UiState("失敗しました", e.message ?: "もう一度かざしてください", Hub.ERR))
                notifyDone("受信に失敗しました", e.message ?: "もう一度かざしてください", emptyList())
            } finally {
                receiving = false
                h.postDelayed({ if (!receiving) Hub.post(idleState()) }, 4000)
                finishIfIdle()
            }
        }
    }
}
